# SETUP PROJECT

- B1: Tạo database với tên smart_tech
- B2: Chạy script trong thư mục ./database với DB vừa tạo ở B1
- B3: Tạo firebase tại https://firebase.google.com
- B3.1: Click `Get started` -> Add new project
- B3.2: Sau khi tạo firebase, trên thanh sidebar, chọn `build` -> `storage` -> `Get started` ( next next là được nhé)
- B3.3: Sau khi tạo `Storage`, chọn `Rule`, sửa `if false` thành `if true`
- B3.4: Trên thanh sidebar, chọn hình bánh răng -> chọn `Project settings` -> `Service account` -> `Generate new private key`
- B4: Tại project, tạo thư mục `firebase.json` trong thư mục `src/main/resources` và copy toàn bộ nội dung từ file đã tải ở B3.4
- B5: Trong file `application.properties`, sửa `firebase.bucket=??` thành `firebase.bucket={1}.appspot.com`
     * #### lưu ý: {1} là project_id trong fie `firebase.json`

### Lưu ý: 
- Chú ý thay đổi thông tin database trong application.properties
- Thông tin tài khoản để truy cập trang ADMIN là `admin@gmail.com/123456`
