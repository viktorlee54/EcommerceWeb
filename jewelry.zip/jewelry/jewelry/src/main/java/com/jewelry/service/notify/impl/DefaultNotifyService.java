package com.jewelry.service.notify.impl;

import com.jewelry.service.notify.INotifyService;
import com.jewelry.service.notify.model.Notification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@Slf4j
public class DefaultNotifyService implements INotifyService {
    @Override
    public void send(Notification notification, Map<String, Object> additionalInfo) {
        log.info("notify function is pending");
    }
}
