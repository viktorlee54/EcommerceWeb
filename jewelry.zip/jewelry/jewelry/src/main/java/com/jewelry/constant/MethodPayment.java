package com.jewelry.constant;

import com.jewelry.service.payment.CODPaymentService;
import com.jewelry.service.payment.IPaymentService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum MethodPayment {
    COD("COD", CODPaymentService.class);
//    PAYPAL("Ví Paypal", PaypalPaymentService.class),

    public final String label;
    public final Class<? extends IPaymentService> implementClass;
}
