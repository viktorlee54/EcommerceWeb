package com.jewelry.service;

import com.jewelry.constant.ImageType;
import com.jewelry.dto.product.ColorProductDTO;
import com.jewelry.dto.product.ProductDetailRequest;
import com.jewelry.dto.product.ProductResponse;
import com.jewelry.entity.Image;
import com.jewelry.entity.Product;
import com.jewelry.entity.Specifications;
import com.jewelry.exception.ValidationException;
import com.jewelry.repository.ImageRepository;
import com.jewelry.repository.ProductRepository;
import com.jewelry.repository.SpecificationsRepository;
import com.jewelry.repository.custom.CustomProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ProductDetailService {
    private final ProductRepository productDao;
    private final ImageRepository imageDao;
    private final CustomProductRepository customProductRepository;
    private final SpecificationsRepository specificationsRepository;

    public ProductResponse getDetailProduct(String productCode) {
        Product product = this.productDao.findByCode(productCode).orElseThrow(() -> new ValidationException(productCode + " không tồn tại"));
        Image image = this.imageDao.findByTypeAndObjectId(ImageType.PRODUCT, String.valueOf(product.getId())).orElse(new Image());
        List<Specifications> byProductId = this.specificationsRepository.findByProductId(product.getId());
        ProductResponse productResponse = new ProductResponse();
        productResponse.setCode(product.getCode());
        productResponse.setName(product.getName());
        productResponse.setImage(image.getUrl());
        productResponse.setId(product.getId());
        productResponse.setCreatedDate(product.getCreatedDate());
        productResponse.setDescription(product.getDescription());
        productResponse.setCategoryId(product.getCategoryId());
        productResponse.setIsShowHome(product.getIsShowHome());
        productResponse.setShortDescription(product.getShortDescription());
        productResponse.setSpecifications(byProductId);

        Map<ColorProductDTO, List<ProductDetailRequest>> details = this.customProductRepository.getSizeAndColorProduct(product.getId());
        productResponse.setDetails(details);
        return productResponse;
    }
}
