package com.jewelry.service.payment;

import com.jewelry.dto.order.CreateOrderRequest;
import com.jewelry.dto.payment.PaymentResponse;
import com.jewelry.entity.Order;

import java.util.Map;

public interface IPaymentService {
    PaymentResponse payment(CreateOrderRequest createOrderRequest);
    Order afterPayment(CreateOrderRequest createOrderRequest, Map<String, Object> data);
    void refund(Order order);
    boolean isPaymentOnline();
}
