package com.jewelry.dto.cart;

import lombok.Data;

@Data
public class UpdateCart {
    private Long id;
    private Integer quantity;
}
