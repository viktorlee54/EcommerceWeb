package com.jewelry.constant;

public enum StatisticType {
    MONTH,
    YEAR,
    NONE;
}
