package com.jewelry.constant;

public enum RoleConstant {
    USER, ADMIN
}
