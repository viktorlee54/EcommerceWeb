package com.jewelry.dto.user;

import com.jewelry.constant.RoleConstant;
import com.jewelry.dto.page.PageRequest;
import lombok.Data;

@Data
public class UserSearchRequest extends PageRequest {
    private String email;
    private Boolean active;
    private String name;
    private RoleConstant role;
    private String currentUser;
}
