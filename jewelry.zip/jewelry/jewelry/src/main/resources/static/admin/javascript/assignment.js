'use-strict'
const ctnAssignment = document.getElementById('assignment-container');
ctnAssignment.lastElementChild.scrollIntoView({behavior: 'smooth'})